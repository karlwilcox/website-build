#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <time.h>
#include <dos.h>
#include <string.h>

#define DEBUG 0x00		/* default is no debugging */
#define ITEMLENGTH	64
#define LINELENGTH	132
#define TIMESLOTS	24
#define TIMESLICE	10
#define STARTHOUR	9

#define WARN 1		/* default is to print warnings */
#define MATCHFILE 	"matches.csv"
#define PITCHFILE	"pitches.csv"
#define TEAMFILE	"hometeams.csv"
#define MATCHDAYFILE	"matchdays.csv"
#define OUTPUTFILE	"fixtures.htm"
#define CONFIGFILE	"config.csv"

/* Bits for the HTML page */
#define BODYFORMAT  " "
#define TABLEFORMAT "border=\"1\" cellspacing=\"0\" cellpadding=\"0\" width=\"95%\"" 
#define PAGETITLE	"Fixture List"
#define HEAD1		"Home Fixture List"
#define HEAD2		1

struct pitchtype {
	int index;
	char *pitchcode;
	char *pitchname;
	struct pitchtype *next;
};

struct daytype {
	int day;
	int month;
	int year;
	char *comment;
	char *notes;
	struct daytype *next;
};

struct teamtype {
	char *teamname;
	char *cellformat;
	char *linkURL;
	struct teamtype *next;
};

struct matchtype {
	int index;
	int day;
	int month;
	int year;
	char *hometeam;
	struct teamtype *homelink;
	char *awayteam;
	struct teamtype *awaylink;
	int starthour;
	int startmin;
	int duration;
	struct pitchtype *pitch;
	struct matchtype *next;
};


struct matrixtype {
	struct daytype *date;
	struct pitchtype *pitch;
	struct matchtype *slots[TIMESLOTS];
	struct matrixtype *next;
};

struct matchtype *matches;
struct pitchtype *pitches;
struct matrixtype *matrix;
struct teamtype *hometeams;
struct daytype *matchdays;

int dowarn;
int debug;
char matchfilename[LINELENGTH];
char pitchfilename[LINELENGTH];
char teamfilename[LINELENGTH];
char matchdayfilename[LINELENGTH];
char outputfilename[LINELENGTH];
char introfilename[LINELENGTH];

char pagetitle[LINELENGTH];
char bodyformat[LINELENGTH];
char tableformat[LINELENGTH];
char head1[LINELENGTH];
int head2;

void initialise ( )
{
	debug = DEBUG;
	dowarn = WARN;
	strcpy ( matchfilename, MATCHFILE );
	strcpy ( pitchfilename, PITCHFILE );
	strcpy ( teamfilename, TEAMFILE );
	strcpy ( matchdayfilename, MATCHDAYFILE );
	strcpy ( outputfilename, OUTPUTFILE );
	introfilename[0] = '\0';

	strcpy ( pagetitle, PAGETITLE );
	strcpy ( head1, HEAD1 );
	strcpy ( bodyformat, BODYFORMAT );
	strcpy ( tableformat, TABLEFORMAT );
	head2 = HEAD2;

	hometeams = (struct teamtype*)0;
	matches = (struct matchtype*)0;
	pitches = (struct pitchtype*)0;
	matchdays = (struct daytype*)0;
}

void warning ( level, str1, str2 )
int level;
char *str1, *str2;
{
	if ( level >= dowarn )
		printf ( "WARNING: %s %s\n" , str1, str2 );
}

char *readCSVitem ( source, target )
char *source;
char *target;
{
	char *cp1, *cp2;

	cp1 = source;
	cp2 = target;
	*cp2 = '\0';

	while ( iswspace ( *cp1 ))
		cp1++;
	if ( *cp1 == '\0' || *cp1 == '\n' || *cp1 == '\r' )
		return ( cp1 );

	if ( *cp1 == '"' )
	{
		cp1++;
		while ( *cp1 != '\0' && *cp1 != '"' )
		{
			if ( *cp1 == '\\' )
				cp1++;	/* we can escape " with \" */
			*cp2++ = *cp1++;
		}
		if ( *cp1 != '\0' )
			cp1++;
		if ( *cp1 == ',' )
			cp1++;
			
	} else {
		while ( *cp1 != '\0' && *cp1 != ',' && *cp1 != '\n' && *cp1 != '\r')
			*cp2++ = *cp1++;
		if ( *cp1 == ',' || *cp1 == '\n' || *cp1 == '\r' )
			cp1++;
	}
	*cp2 = '\0';
	return ( cp1 );
}

int getconfig ( filename )
char *filename;
{
	FILE *configfile;
	char line[LINELENGTH];
	char configitem[ITEMLENGTH];
	char configvalue[LINELENGTH];
	char *temp;

	if ( (configfile = fopen ( filename, "r" )) == NULL )
		return ( 1 );
	while ( fgets ( line, LINELENGTH, configfile ) != NULL )
	{
		if ( line[0] == '\0' || line[0] == '\n' || line[0] == '#' )
			continue;
		temp = line;
		temp = readCSVitem( temp, configitem );
		temp = readCSVitem( temp, configvalue );
		if ( strcmpi ( configitem, "warninglevel" ) == 0 )
		    dowarn = atoi ( configvalue );
		else if ( strcmpi ( configitem, "debuglevel" ) == 0 )
		    debug = atoi ( configvalue );
		else if ( strcmpi ( configitem, "matchfile" ) == 0 )
		    strcpy ( matchfilename, configvalue );
		else if ( strcmpi ( configitem, "pitchfile" ) == 0 )
		    strcpy ( pitchfilename, configvalue );
		else if ( strcmpi ( configitem, "teamfile" ) == 0 )
		    strcpy ( teamfilename, configvalue );
		else if ( strcmpi ( configitem, "matchdayfile" ) == 0 )
		    strcpy ( matchdayfilename, configvalue );
		else if ( strcmpi ( configitem, "outputfile" ) == 0 )
		    strcpy ( outputfilename, configvalue );
		else if ( strcmpi ( configitem, "introfile" ) == 0 )
		    strcpy ( introfilename, configvalue );
		else if ( strcmpi ( configitem, "pagetitle" ) == 0 )
		    strcpy ( pagetitle, configvalue );
		else if ( strcmpi ( configitem, "bodyformat" ) == 0 )
		    strcpy ( bodyformat, configvalue );
		else if ( strcmpi ( configitem, "tableformat" ) == 0 )
		    strcpy ( tableformat, configvalue );
		else if ( strcmpi ( configitem, "head1" ) == 0 )
		    strcpy ( head1, configvalue );
		else if ( strcmpi ( configitem, "head2" ) == 0 )
		    head2 = atoi ( configvalue );
		else
		    warning ( 1, "Unknown configuration item", configitem );
	}
	fclose ( configfile );
	return ( 0 );
}

int getteams ( filename )
char *filename;
{
	FILE *teamfile;
	char line[LINELENGTH];
	char item[ITEMLENGTH];
	char *temp;
	struct teamtype *tptr;

	if ( (teamfile = fopen ( filename, "r" )) == NULL )
		return ( 1 );

	while ( fgets ( line, LINELENGTH, teamfile ) != NULL )
	{
		if ( line[0] == '\0' || line[0] == '\n' || line[0] == '#' )
			continue;
		/* got some team information */
		if ( hometeams == (struct teamtype*)0 )
		{
			hometeams = malloc ( sizeof (struct teamtype ));
			tptr = hometeams;
		}
		else
		{
			tptr = hometeams;
			while ( tptr->next != (struct teamtype*)0)
				tptr = tptr->next;
			tptr->next = (struct teamtype*) malloc ( sizeof ( struct teamtype ));
			tptr = tptr->next;
		}
		tptr->next = (struct teamtype*)0;
			
		temp = line;
		temp = readCSVitem( temp, item);
		tptr->teamname = (char *) strdup ( item );
		temp = readCSVitem( temp, item);
		if ( item[0] == '\0' )
			tptr->cellformat = (char *)0;
		else
		tptr->cellformat = (char *) strdup ( item );
		temp = readCSVitem( temp, item);
		if ( item[0] == '\0' )
			tptr->linkURL = (char *)0;
		else
			tptr->linkURL = (char *) strdup ( item );
	}
	fclose ( teamfile );
	tptr = hometeams;
	if ( debug & 0x01 )
	{
		while ( tptr != (struct teamtype*)0 )
		{
			printf ( "%s - %s - %s\n", tptr->teamname, tptr->cellformat,
				tptr->linkURL );
			tptr = tptr->next;
		}
	}	
	return ( 0 );
}

int getmatchdays ( filename )
char *filename;
{
	FILE *matchdayfile;
	char line[LINELENGTH];
	char item[ITEMLENGTH];
	char *temp;
	struct daytype *tptr;
	char *t2;

	if ( (matchdayfile = fopen ( filename, "r" )) == NULL )
		return ( 1 );

	while ( fgets ( line, LINELENGTH, matchdayfile ) != NULL )
	{
		if ( line[0] == '\0' || line[0] == '\n' || line[0] == '#' )
			continue;
		if ( matchdays == (struct daytype*)0 )
		{
			matchdays = malloc ( sizeof (struct daytype ));
			tptr = matchdays;
		}
		else
		{
			tptr = matchdays;
			while ( tptr->next != (struct daytype*)0)
				tptr = tptr->next;
			tptr->next = (struct daytype*) malloc ( sizeof ( struct daytype ));
			tptr = tptr->next;
		}
		tptr->next = (struct daytype*)0;
		temp = line;
		temp = readCSVitem( temp, item );
		t2 = item;
		tptr->day = atoi ( t2 );
		while ( isdigit( *t2 ))
			t2++;
		tptr->month = atoi ( ++t2 );
		while ( isdigit( *t2 ))
			t2++;
		tptr->year = atoi ( ++t2 );
		if (tptr->year > 2000)
		    tptr->year -= 2000;
		temp = readCSVitem( temp, item );
		if ( item[0] != '\0' )
			tptr->comment = (char *)strdup(item);
		else
			tptr->comment = (char *)0;
		temp = readCSVitem( temp, item );
		if ( item[0] != '\0' )
			tptr->notes = (char *)strdup(item);
		else
			tptr->notes = (char *)0;
		if ( debug >= 1 )
			printf ( "%d/%d/%d - %s - %s\n", tptr->day, tptr->month, tptr->year,
			 tptr->comment, tptr->notes );
	}
	fclose ( matchdayfile );
	return ( 0 );
}


	
int getpitches ( filename )
char *filename;
{
	FILE *pitchfile;
	char line[LINELENGTH];
	char item[ITEMLENGTH];
	char *temp;
	struct pitchtype *tptr;
	int count;
	
	count = 0;

	if ( (pitchfile = fopen ( filename, "r" )) == NULL )
		return ( 1 );

	while ( fgets ( line, LINELENGTH, pitchfile ) != NULL )
	{
		if ( line[0] == '\0' || line[0] == '\n' || line[0] == '#' )
			continue;
		if ( pitches == (struct pitchtype*)0 )
		{
			pitches = malloc ( sizeof (struct pitchtype ));
			tptr = pitches;
		}
		else
		{
			tptr = pitches;
			while ( tptr->next != (struct pitchtype*)0)
				tptr = tptr->next;
			tptr->next = (struct pitchtype*) malloc ( sizeof ( struct pitchtype ));
			tptr = tptr->next;
		}
		tptr->index = count++;
		tptr->next = (struct pitchtype*)0;
		temp = line;
		temp = readCSVitem( temp, item );
		tptr->pitchcode = (char *)strdup(item);
		temp = readCSVitem( temp, item );
		tptr->pitchname = (char *)strdup(item);
		if ( debug & 0x01 )
			printf ( "%s - %s\n", tptr->pitchcode, tptr->pitchname );
	}
	fclose ( pitchfile );
	return ( 0 );
}

int getmatches ( filename )
char *filename;
{
	FILE *matchfile;
	char line[LINELENGTH];
	char item[ITEMLENGTH];
	char warn1[LINELENGTH];
	char *temp, *t2;
	int count;
	struct matchtype *tptr;
	struct pitchtype *pptr;
	struct teamtype *tmptr;

	if ( (matchfile = fopen ( filename, "r" )) == NULL )
		return ( 1 );

	count = 0;

	while ( fgets ( line, LINELENGTH, matchfile ) != NULL )
	{
		if ( line[0] == '\0' || line[0] == '\n' || line[0] == '#' )
			continue;
		if ( matches == (struct matchtype*)0 )
		{
			matches = malloc ( sizeof (struct matchtype ));
			tptr = matches;
		}
		else
		{
			tptr = matches;
			while ( tptr->next != (struct matchtype*)0)
				tptr = tptr->next;
			tptr->next = (struct matchtype*) malloc ( sizeof ( struct matchtype ));
			tptr = tptr->next;
		}
		tptr->index = count++;
		tptr->next = (struct matchtype*)0;
		temp = line;
		temp = readCSVitem( temp, item );
		t2 = item;
		tptr->day = atoi ( t2 );
		while ( isdigit( *t2 ))
			t2++;
		tptr->month = atoi ( ++t2 );
		while ( isdigit( *t2 ))
			t2++;
		tptr->year = atoi ( ++t2 );
		if (tptr->year > 2000)
		    tptr->year -= 2000;
		temp = readCSVitem( temp, item );
		tptr->hometeam = (char *)strdup(item);
		tptr->homelink = (struct teamtype *)0;		
		tmptr = hometeams;
		while ( tmptr != (struct teamtype *)0 )
		{
			if ( strcmpi ( tmptr->teamname, tptr->hometeam ) == 0 )
			{
				tptr->homelink = tmptr;
				break;
			}
			tmptr = tmptr->next;
		}
		if (tptr->homelink == (struct teamtype *)0 )
			warning ( 1, "unknown home team", tptr->hometeam );
	    sprintf ( warn1, "%d/%d/%d %s", tptr->day, tptr->month, tptr->year,
	                tptr->hometeam ); /* might need this for warnings later */
		temp = readCSVitem( temp, item );
		if ( item[0] == '\0' )
			tptr->awayteam = (char *)0;
		else
			tptr->awayteam = (char *)strdup(item);
		temp = readCSVitem( temp, item );
		t2 = item;
		tptr->starthour = atoi ( t2 );
		if ( tptr->starthour < STARTHOUR ) /*idiot check */
		{
		    warning ( 2, warn1, "Game starts before start time" );
		    tptr->starthour = STARTHOUR;
		}
		while ( isdigit( *t2 ))
			t2++;
		tptr->startmin = atoi ( ++t2 );
		if ( tptr->startmin > 59 ) /* idiot check */
		{
		    warning ( 2, warn1, "minutes > 59" );
		    tptr->startmin = 59;
		}
		temp = readCSVitem( temp, item );
		tptr->duration = atoi ( item );
		temp = readCSVitem( temp, item );
		pptr = pitches;
		while ( pptr != (struct pitchtype*)0 )
		{
			if ( strcmpi ( pptr->pitchcode, item ) == 0 )
			{
				tptr->pitch = pptr;
				break;
			}
			pptr = pptr->next;
		}
		if (debug & 0x01)
			printf ( "%d - %d/%d/%d - %s - %s - %d:%d %d %d\n",
				tptr->index,
				tptr->day, tptr->month, tptr->year,
				tptr->hometeam, tptr->awayteam,
				tptr->starthour, tptr->startmin,
				tptr->pitch->index, tptr->duration );		
	}
	fclose ( matchfile );	
	return ( 0 );
}

int startslot ( hour, min )
{
	return ( ((hour - STARTHOUR) * (60 / TIMESLICE)) + (min/ TIMESLICE ) );
}

void buildmatrix ( )
{
	struct matrixtype *tptr;
	struct pitchtype *pptr;
	struct daytype *mdptr;
	int i, c1;

	mdptr = matchdays;

	/* for each match day */
	while ( mdptr != (struct daytype*)0 )
	{
		/* and for each pitch */
		pptr = pitches;
		while ( pptr != (struct pitchtype*)0 )
		{
			if ( matrix == (struct matrixtype*)0 )
			{
				matrix = (struct matrixtype*) 
						malloc ( sizeof (struct matrixtype ));
				tptr = matrix;
			}
			else
			{
				tptr->next = (struct matrixtype*) 
						malloc ( sizeof (struct matrixtype ));
				tptr = tptr->next;
			}
			tptr->date = mdptr;
			tptr->pitch = pptr;
			for ( i = 0; i < TIMESLOTS; i++ )
				tptr->slots[i] = (struct matchtype*)0;
			pptr = pptr->next;
		}
		mdptr = mdptr->next;

	}
	tptr->next = (struct matrixtype*)0;

}
	

void populatematrix ( )
{
	int c1;	
	int i;
	int start, end;
	struct matrixtype *tptr;
	struct pitchtype *pptr;
	struct matchtype *mptr;
	char warn1[LINELENGTH], warn2[LINELENGTH];

	mptr = matches;

	while ( mptr != (struct matchtype*)0 )
	{
		/* Is this match date in the matrix? */
		tptr = matrix;
		while ( tptr != (struct matrixtype *)0 )
		{
			if ( 	mptr->day == tptr->date->day &&
			    	mptr->month == tptr->date->month &&
				mptr->year == tptr->date->year &&
				mptr->pitch == tptr->pitch )
			{
				/* found a match */
				start = startslot ( mptr->starthour,
					 mptr->startmin );
				end = start + (mptr->duration / 10);
				if ( end > TIMESLOTS ) /* truncate matches ending after 12:00 */
				    end = TIMESLOTS;
				for ( i = start; i < end ; i++ )
				{
					if ( tptr->slots[i] == 
						(struct matchtype*)0 )
					{
						tptr->slots[i] = mptr;
					}
					else
					{	
						sprintf ( warn1, "%d/%d/%d Clash on %s",
							mptr->day, mptr->month, mptr->year,
							mptr->pitch->pitchname );
						sprintf ( warn2, "between %s and %s",
							mptr->hometeam,
							tptr->slots[i]->hometeam );
						warning ( 1, warn1, warn2 );
					}
				}
			}
			tptr = tptr->next;
		}
		mptr = mptr->next;
	}

	if (debug & 0x02)
	{
		tptr = matrix;
		while ( tptr != (struct matrixtype*)0 )
		{
			printf ( "%d/%d/%d %d ", tptr->date->day, 
				tptr->date->month, tptr->date->year,
				tptr->pitch->index );
			for ( c1 = 0; c1 < TIMESLOTS; c1++ )
				if ( tptr->slots[c1] == (struct matchtype*)0 )
					putchar ( '.' );
				else
					printf ( "%d", tptr->slots[c1]->index );
			putchar ( '\n' );
			tptr = tptr->next;
		}
	}
}

void printmatrix ( filename )
char *filename;
{
	FILE *out;
	FILE *intro;
	char line[LINELENGTH];
	struct tm *tm;
	time_t t;
	struct matrixtype *mptr, *tptr;
	int i, j;

	if ( (out = fopen ( filename, "w" )) == NULL )
	{
		printf ( "Could not open output file %s\n", filename );
		return;
	}
	t = time(NULL);
	tm = localtime ( &t );
	mptr = matrix;

	fprintf ( out, "<html>\n<head><title>%s</title></head>\n", pagetitle );
	fprintf ( out, "<body %s>\n", bodyformat );
	fprintf ( out, "<h1 align=\"center\">%s</h1>\n", head1 );
	if ( head2 )
	fprintf ( out, "<h2 align=\"center\">Issue Date - %02d / %02d / %02d</h2>\n",
		tm->tm_mday, tm->tm_mon + 1, tm->tm_year - 100 );
	fprintf ( out, "<p>&nbsp</p>\n" );
	/* If there is an intro file, just copy the contents to the output */
	if ( introfilename[0] != '\0' && (intro = fopen ( introfilename, "r" )) != NULL )
	{
	    while ( fgets ( line, LINELENGTH, intro ) != NULL )
	        fprintf ( out, "%s", line );
	}
	do
	{
		fprintf ( out, "<table %s>\n", tableformat );
		fprintf ( out, "<tr>\n<td rowspan=\"2\" width=\"8.8%%\"><B>%02d/%02d/%02d</B>",
		     mptr->date->day, mptr->date->month, mptr->date->year );
		if ( mptr->date->comment != (char *)0 )
			fprintf ( out, "<br>%s", mptr->date->comment );
		fprintf ( out, "</td>\n" );
		for ( i = 0; i < 4; i++ )
		{
			fprintf ( out, "<td align=\"center\", colspan=\"%d\">%02d</td>\n", 6,
				STARTHOUR + i );
		}
		fprintf ( out, "</tr>\n<tr>\n" );
		for ( i = 0; i < 4; i++ )
		{
			for ( j = 0; j < 6; j++ )
			{
				fprintf ( out, "<td align=\"left\" width=\"3.8%%\">%02d</td>\n",
					j * TIMESLICE );
			}
		}
		fprintf ( out, "</tr>\n" );
		    do
		    {
			fprintf ( out, "<tr>\n<td>%s</td>\n", mptr->pitch->pitchname );
			for ( i = 0; i < TIMESLOTS; i++ )
			{
				if ( mptr->slots[i] == (struct matchtype *)0 )
					fprintf ( out, "<td>&nbsp</td>\n" );
				else
				{
					j = 1;
					while ( mptr->slots[i] == mptr->slots[i+j] )
						j++;
					fprintf ( out, "<td colspan=\"%d\" align=\"center\"", j );
					if ( mptr->slots[i]->homelink != (struct teamtype*)0
						&& mptr->slots[i]->homelink->cellformat !=
								(char *)0 )
					{
						fprintf ( out, " %s ",
						   mptr->slots[i]->homelink->cellformat );
					}
					fprintf ( out, ">" );
					if ( mptr->slots[i]->homelink != (struct teamtype*)0
						&& mptr->slots[i]->homelink->linkURL !=
								(char *)0 )
					{
						fprintf ( out, "<a href=\"%s\">%s</a>",
						  mptr->slots[i]->homelink->linkURL,
						  mptr->slots[i]->hometeam );
					}
					else
						fprintf ( out, "%s",
  						       mptr->slots[i]->hometeam );
					if ( mptr->slots[i]->awayteam != (char *)0 )
						fprintf ( out, " v %s", 
						mptr->slots[i]->awayteam );
					fprintf ( out, "</td>\n" );
					i += j - 1;
				}
			}
			fprintf ( out, "</tr>\n" );
			tptr = mptr;
			mptr = mptr->next;
		    } while ( mptr != (struct matrixtype *)0 && tptr->date == mptr->date );
		fprintf ( out, "</table>\n\n" );
		if ( tptr->date->notes != (char *)0 )
		    fprintf ( out, "<P>%s<P>\n", tptr->date->notes );
		else
		    fprintf ( out, "<p>&nbsp</p>\n" );
	} while ( mptr != (struct matrixtype *)0 );
			

	fprintf ( out, "</body>\n</html>\n" );
	fclose ( out );
}

int main ( argc, argv )
int argc;
char *argv[];
{
	initialise ();
	if ( argc > 1 )
	{
	    /* we assume one argument, the name of the config file */
	    getconfig ( argv[1] );
	}
	getteams ( teamfilename );
	getmatchdays ( matchdayfilename );
	getpitches ( pitchfilename );
	getmatches ( matchfilename );
	buildmatrix();
	populatematrix();
	printmatrix ( outputfilename );
	return ( 0 );
}

